from django.contrib import admin
from psicologo.models import Psicologo, Agenda

admin.site.register(Psicologo)
admin.site.register(Agenda)