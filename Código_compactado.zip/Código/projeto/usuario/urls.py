from os import name
from django import views
from django.urls import path
from .views import UserListView, UserDetailView, UserCreateView

urlpatterns = [
path('', UserListView.as_view(), name='user_list'),
path('<int:pk>/', UserDetailView.as_view(), name='user_detail'),
path('new/', UserCreateView.as_view(), name)


# URL para o formulário de login do usuário
path('login/', views.login_view, name='login'),

# URL para o formulário de registro do usuário
 path('register/', views.register_view, name='register'),

# URL para o formulário de edição do perfil do usuário
path('profile/edit/', views.edit_profile_view, name='edit_profile'),

# URL para o formulário de alteração de senha do usuário
path('password/change/', views.change_password_view, name='change_password'),     

# URL para o formulário de criação de post
path('posts/create/', views.create_post_view, name='create_post'),

# URL para o formulário de edição de post
path('posts/<int:pk>/edit/', views.edit_post_view, name='edit_post'),

# URL para o formulário de exclusão de post
path('posts/<int:pk>/delete/', views.delete_post_view, name='delete_post'),

# URL para o formulário de criação de comentário
path('comments/create/', views.create_comment_view, name='create_comment'),

# URL para o formulário de edição de comentário
path('comments/<int:pk>/edit/', views.edit_comment_view, name='edit_comment'),

# URL para o formulário de exclusão de comentário
path('comments/<int:pk>/delete/', views.delete_comment_view, name='delete_comment'),

]



