
from django.contrib import admin
from usuario.models import Usuario, Post, Comentario, Avaliacao

admin.site.register(Usuario)
admin.site.register(Post)
admin.site.register(Comentario)
admin.site.register(Avaliacao)


