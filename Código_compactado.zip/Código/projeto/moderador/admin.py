from django.contrib import admin
from moderador.models import Moderador

admin.site.register(Moderador)
